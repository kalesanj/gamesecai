// index.js — serve frontend + call Gemini API safely (free-tier friendly)
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// Serve static files from /public
app.use(express.static(path.join(__dirname, "public")));

function sanitize(txt = "") {
  return String(txt).replace(/https?:\/\/\S+/g, "[link]").replace(/\S+@\S+/g, "[email]").slice(0, 600);
}

const cache = new Map();
function getCache(k){ return cache.get(k); }
function setCache(k,v){ cache.set(k,v); }

async function geminiCall({ model = "gemini-1.5-flash", text }) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("Missing GEMINI_API_KEY");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const body = {
    contents: [{ role: "user", parts: [{ text }] }],
    generationConfig: { temperature: 0.3, maxOutputTokens: 220 }
  };
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`Gemini error: ${r.status} ${await r.text()}`);
  const j = await r.json();
  return j?.candidates?.[0]?.content?.parts?.[0]?.text || "No response.";
}

app.post("/ask-definition", async (req, res) => {
  try {
    const term = sanitize(req.body.term || "");
    const key = `def:${term.toLowerCase()}`;
    const hit = getCache(key);
    if (hit) return res.json({ text: hit });

    const prompt = `You are a concise cybersecurity tutor. Explain terms in 2–4 safe sentences.\n\nExplain the term: ${term}`;
    const textOut = await geminiCall({ text: prompt });

    setCache(key, textOut);
    res.json({ text: textOut });
  } catch (e) {
    res.status(500).json({ error: "AI error" });
  }
});

app.post("/answer-feedback", async (req, res) => {
  try {
    const { question, selectedOptionText, correct, confidence, hesitationMs, explanation } = req.body || {};
    const userMsg = `
Question: ${sanitize(question)}
User's answer: ${sanitize(selectedOptionText)}
Correct? ${correct ? "Yes" : "No"}
Confidence (1-5): ${confidence}
Hesitation ms: ${hesitationMs}
Reference explanation (safe to cite): ${sanitize(explanation)}
Provide short, supportive feedback (3–6 sentences) and one safe tip.`;
    const prompt = `You are a helpful cybersecurity explainer. Avoid operational hacking instructions.\n\n${userMsg}`;
    const textOut = await geminiCall({ text: prompt });
    res.json({ text: textOut });
  } catch (e) { res.status(500).json({ error: "AI error" }); }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`GameSecAI (Gemini) running on port ${PORT}`));
